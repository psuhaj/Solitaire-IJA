#!/bin/sh

unzip -q $package.zip
make