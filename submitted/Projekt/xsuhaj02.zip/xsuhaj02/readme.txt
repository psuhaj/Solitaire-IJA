Hra Solitaire Klondike

Autori : Adrián Tóth(xtotha01)
         Peter Šuhaj(xsuhaj02)

Tento projekt je implementácia hry Klondike Solitaire do predmetu Seminár Java v akademickom roku 2016/2017.
